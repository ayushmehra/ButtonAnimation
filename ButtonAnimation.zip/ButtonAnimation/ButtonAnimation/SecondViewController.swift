//
//  SecondViewController.swift
//  ButtonAnimation
//
//  Created by Ayush Mehra on 20/04/20.
//  Copyright © 2020 Ayush Mehra. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var btnLogout: AMTransitionButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnLogOutTapped(_ sender: Any) {
        btnLogout.moveToCenterExpand(0) {[unowned self] in
            self.navigationController?.popViewController(animated: true)
               //    self.dismiss(animated: false, completion: nil)
               }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
