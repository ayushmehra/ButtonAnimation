//
//  ViewController.swift
//  ButtonAnimation
//
//  Created by Ayush Mehra on 20/04/20.
//  Copyright © 2020 Ayush Mehra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var btnAnimate: AMTransitionButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        btnAnimate.startShakeAnimation(1, completion: {
                  self.btnAnimate.setTitle("Login", for: .normal)
               })
    }
    @IBAction func onTapButton(_ button: AMTransitionButton) {
        
    
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            button.startLoadingAnimation()
            self.btnAnimate.startShakeAnimation(1, completion: {
                let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                guard let changePwdViewController = storyBoard.instantiateViewController(withIdentifier: "SecondViewController") as? SecondViewController else {
                           return
                       }
                       self.navigationController?.pushViewController(changePwdViewController, animated: true)


            })
        
        }

    }
    
}

